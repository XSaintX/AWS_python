import json
import os
from db.database import DataBase

def lambda_handler(event, context):
    print("Received event: ", event)
    print("Context: ", context)
    body_response = {
        "message": "Hola",
        "host": os.environ.get("POSTGRES_HOST"),
        "port": os.environ.get("POSTGRES_PORT"),
        "password": os.environ.get("POSTGRES_PASSWORD"),
        "user": os.environ.get("POSTGRES_USER"),
        "database": os.environ.get("POSTGRES_DB")
    }
    db = DataBase()
    users = db.get_users()
    print("Users: ", users)
    return {
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "statusCode": 200,
        "body": json.dumps(body_response)
    }
